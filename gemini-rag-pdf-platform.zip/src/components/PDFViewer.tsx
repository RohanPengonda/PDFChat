import { useState, useEffect, useRef } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';
import { clsx } from 'clsx';

// Set worker
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;

interface PDFViewerProps {
  fileUrl: string | null;
  pageNumber?: number;
  highlightText?: string;
}

export function PDFViewer({ fileUrl, pageNumber = 1, highlightText }: PDFViewerProps) {
  const [numPages, setNumPages] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(pageNumber);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setCurrentPage(pageNumber);
  }, [pageNumber]);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
  }

  // Simple highlighting effect
  useEffect(() => {
    if (!highlightText || !containerRef.current) return;

    // Wait for text layer to render
    const timer = setTimeout(() => {
      const textLayer = containerRef.current?.querySelector('.react-pdf__Page__textContent');
      if (!textLayer) return;

      // Reset previous highlights
      const marks = textLayer.querySelectorAll('mark');
      marks.forEach(mark => {
        const text = mark.textContent;
        mark.replaceWith(text || '');
      });

      // This is a very basic implementation. 
      // Real PDF highlighting requires complex coordinate mapping or sophisticated text matching
      // across multiple span elements.
      // For this demo, we will try to find the text in the spans and highlight it.
      
      // A better approach for "exact text" which might be fragmented across spans:
      // We can't easily wrap across spans without breaking layout.
      // So we will just scroll to the page.
      // But let's try to highlight if it matches a span exactly or partially.
      
      const spans = Array.from(textLayer.querySelectorAll('span'));
      for (const span of spans) {
        if (span.textContent && span.textContent.includes(highlightText)) {
          span.innerHTML = span.textContent.replace(
            highlightText,
            `<mark class="bg-yellow-300/50 text-transparent">${highlightText}</mark>`
          );
          span.scrollIntoView({ behavior: 'smooth', block: 'center' });
          break; // Jump to first occurrence
        }
      }
    }, 500); // Delay to ensure render

    return () => clearTimeout(timer);
  }, [currentPage, highlightText, fileUrl]);

  return (
    <div className="flex flex-col items-center bg-gray-100 h-full overflow-auto p-4" ref={containerRef}>
      {fileUrl ? (
        <Document
          file={fileUrl}
          onLoadSuccess={onDocumentLoadSuccess}
          className="shadow-lg"
          loading={<div className="p-10">Loading PDF...</div>}
        >
          <Page 
            pageNumber={currentPage} 
            renderTextLayer={true}
            renderAnnotationLayer={false}
            width={600}
            className="bg-white"
          />
        </Document>
      ) : (
        <div className="flex items-center justify-center h-full text-gray-500">
          Select a document to view
        </div>
      )}
      
      {fileUrl && (
        <div className="mt-4 flex gap-4 items-center bg-white p-2 rounded shadow sticky bottom-4">
          <button 
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage(prev => prev - 1)}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            Prev
          </button>
          <span>
            Page {currentPage} of {numPages}
          </span>
          <button 
            disabled={currentPage >= numPages}
            onClick={() => setCurrentPage(prev => prev + 1)}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
