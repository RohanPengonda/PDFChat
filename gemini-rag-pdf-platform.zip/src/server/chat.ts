import { GoogleGenAI } from '@google/genai';
import { db } from './db';
import { vectorStore } from './vector';
import { Response } from 'express';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const chatService = {
  async generateResponse(message: string, chatId: string, documentIds: string[] | undefined, res: Response) {
    // 1. Save User Message
    db.addMessage(chatId, 'user', message);

    // 2. Generate Embedding for Query
    const embeddingResponse = await ai.models.embedContent({
      model: "text-embedding-004",
      contents: [{ parts: [{ text: message }] }]
    });
    const queryVector = embeddingResponse.embeddings[0].values;

    // 3. Retrieve Context
    // Filter by documentIds if provided
    const filter = documentIds && documentIds.length > 0 ? { document_ids: documentIds } : undefined;
    const relevantChunks = await vectorStore.query(queryVector, 5, filter);

    // 4. Construct Prompt
    const contextText = relevantChunks.map(chunk => 
      `[File: ${chunk.metadata.document_id} | Page: ${chunk.metadata.page_number}] ${chunk.metadata.text}`
    ).join('\n\n');

    const systemInstruction = `You are a document assistant. Answer ONLY using the provided context. If the answer is not in context, say you do not know. Cite file name and page number clearly.
    
    Context:
    ${contextText}
    `;

    // 5. Generate Response (Streaming)
    const result = await ai.models.generateContentStream({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: [{ text: message }] }],
      config: {
        systemInstruction: systemInstruction
      }
    });

    let fullResponse = '';

    for await (const chunk of result) {
      const chunkText = chunk.text;
      if (chunkText) {
        fullResponse += chunkText;
        res.write(`data: ${JSON.stringify({ text: chunkText })}\n\n`);
      }
    }

    // 6. Save Assistant Message
    db.addMessage(chatId, 'assistant', fullResponse);
    
    // 7. Send Citations (Metadata)
    // We send this as a final event
    const sources = relevantChunks.map(c => ({
      file_name: c.metadata.document_id, // In a real app, join with documents table to get real name
      page_number: c.metadata.page_number,
      chunk_id: c.id,
      text: c.metadata.text.substring(0, 50) + '...'
    }));
    
    res.write(`data: ${JSON.stringify({ sources })}\n\n`);
  }
};
