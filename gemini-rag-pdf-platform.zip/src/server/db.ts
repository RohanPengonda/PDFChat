import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';

// Initialize DB
const dbPath = path.resolve('database.sqlite');
const sqlite = new Database(dbPath);

// Create tables
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    original_name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS chunks (
    id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    content TEXT NOT NULL,
    page_number INTEGER NOT NULL,
    chunk_index INTEGER NOT NULL,
    embedding BLOB, -- Stored as JSON string or binary
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(document_id) REFERENCES documents(id)
  );

  CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    title TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL,
    role TEXT NOT NULL, -- 'user' or 'assistant'
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(chat_id) REFERENCES chats(id)
  );
`);

export const db = {
  // Documents
  createDocument: (id: string, filename: string, originalName: string) => {
    const stmt = sqlite.prepare('INSERT INTO documents (id, filename, original_name) VALUES (?, ?, ?)');
    stmt.run(id, filename, originalName);
    return id;
  },

  getDocuments: () => {
    return sqlite.prepare('SELECT * FROM documents ORDER BY created_at DESC').all();
  },

  getDocument: (id: string) => {
    return sqlite.prepare('SELECT * FROM documents WHERE id = ?').get(id);
  },

  // Chunks
  createChunk: (id: string, documentId: string, content: string, pageNumber: number, chunkIndex: number, embedding: number[]) => {
    const stmt = sqlite.prepare('INSERT INTO chunks (id, document_id, content, page_number, chunk_index, embedding) VALUES (?, ?, ?, ?, ?, ?)');
    stmt.run(id, documentId, content, pageNumber, chunkIndex, JSON.stringify(embedding));
  },

  getChunksByDocument: (documentId: string) => {
    const chunks = sqlite.prepare('SELECT * FROM chunks WHERE document_id = ?').all();
    return chunks.map((c: any) => ({ ...c, embedding: JSON.parse(c.embedding) }));
  },

  getAllChunks: () => {
    const chunks = sqlite.prepare('SELECT * FROM chunks').all();
    return chunks.map((c: any) => ({ ...c, embedding: JSON.parse(c.embedding) }));
  },

  // Chats
  createChat: () => {
    const id = uuidv4();
    const stmt = sqlite.prepare('INSERT INTO chats (id, title) VALUES (?, ?)');
    stmt.run(id, 'New Chat');
    return id;
  },

  // Messages
  addMessage: (chatId: string, role: 'user' | 'assistant', content: string) => {
    const id = uuidv4();
    const stmt = sqlite.prepare('INSERT INTO messages (id, chat_id, role, content) VALUES (?, ?, ?, ?)');
    stmt.run(id, chatId, role, content);
    return id;
  },

  getMessages: (chatId: string) => {
    return sqlite.prepare('SELECT * FROM messages WHERE chat_id = ? ORDER BY created_at ASC').all();
  }
};
