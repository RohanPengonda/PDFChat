import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { GoogleGenAI } from '@google/genai';
import { db } from './db';
import { vectorStore } from './vector';
// Use standard import for pdfjs-dist
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const ingestionService = {
  async processDocument(file: Express.Multer.File): Promise<string> {
    const documentId = uuidv4();
    const filePath = file.path;

    // 1. Store metadata in DB
    db.createDocument(documentId, file.filename, file.originalname);

    // 2. Extract Text
    const pages = await this.extractTextFromPDF(filePath);

    // 3. Chunk Text
    const chunks = this.chunkPages(pages);

    // 4. Generate Embeddings & Store
    // Process in batches to avoid hitting API limits
    const BATCH_SIZE = 5; // Reduced batch size
    for (let i = 0; i < chunks.length; i += BATCH_SIZE) {
      const batch = chunks.slice(i, i + BATCH_SIZE);
      await Promise.all(batch.map(async (chunk) => {
        try {
            const embedding = await this.generateEmbedding(chunk.text);
            
            const chunkId = uuidv4();
            
            // Store in SQL DB
            db.createChunk(
              chunkId, 
              documentId, 
              chunk.text, 
              chunk.pageNumber, 
              chunk.chunkIndex, 
              embedding
            );

            // Store in Vector DB
            await vectorStore.addVectors([{
              id: chunkId,
              values: embedding,
              metadata: {
                document_id: documentId,
                page_number: chunk.pageNumber,
                text: chunk.text
              }
            }]);
        } catch (e) {
            console.error(`Failed to process chunk ${chunk.chunkIndex} for doc ${documentId}`, e);
        }
      }));
    }

    return documentId;
  },

  async extractTextFromPDF(filePath: string): Promise<{ pageNumber: number; text: string }[]> {
    const dataBuffer = fs.readFileSync(filePath);
    const uint8Array = new Uint8Array(dataBuffer);
    
    const loadingTask = pdfjsLib.getDocument({
      data: uint8Array,
      useSystemFonts: true,
      // Disable worker for Node environment to avoid worker file issues
      disableFontFace: true,
    });

    const pdfDocument = await loadingTask.promise;
    const numPages = pdfDocument.numPages;
    const pages = [];

    for (let i = 1; i <= numPages; i++) {
      const page = await pdfDocument.getPage(i);
      const textContent = await page.getTextContent();
      const text = textContent.items.map((item: any) => item.str).join(' ');
      pages.push({ pageNumber: i, text });
    }

    return pages;
  },

  chunkPages(pages: { pageNumber: number; text: string }[]): { text: string; pageNumber: number; chunkIndex: number }[] {
    const chunks: { text: string; pageNumber: number; chunkIndex: number }[] = [];
    const CHUNK_SIZE = 1000; // Characters roughly
    const OVERLAP = 100;

    let globalChunkIndex = 0;

    for (const page of pages) {
      const text = page.text;
      if (text.length <= CHUNK_SIZE) {
        chunks.push({ text, pageNumber: page.pageNumber, chunkIndex: globalChunkIndex++ });
        continue;
      }

      let start = 0;
      while (start < text.length) {
        const end = Math.min(start + CHUNK_SIZE, text.length);
        const chunkText = text.slice(start, end);
        chunks.push({ text: chunkText, pageNumber: page.pageNumber, chunkIndex: globalChunkIndex++ });
        start += (CHUNK_SIZE - OVERLAP);
      }
    }

    return chunks;
  },

  async generateEmbedding(text: string): Promise<number[]> {
    try {
      // Use text-embedding-004 as it's the current standard, embedding-001 is older
      const response = await ai.models.embedContent({
        model: "text-embedding-004",
        contents: [{ parts: [{ text }] }]
      });
      return response.embeddings[0].values;
    } catch (error) {
      console.error('Embedding error:', error);
      throw error;
    }
  }
};
